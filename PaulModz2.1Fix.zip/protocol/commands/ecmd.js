module.exports = {
    // Client Commands
    'ChangeAvatar': 505,

    '505': 'ChangeAvatar'
}